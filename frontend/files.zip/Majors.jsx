import { Link } from "react-router-dom";
import StudentLayout from "../../layouts/StudentLayout";
import { styles } from "../../styles/comingSoonStyles";

export default function Majors() {
  return (
    <StudentLayout>
      <div style={styles.wrap}>
        <div style={styles.icon}>🎓</div>
        <span style={styles.eyebrow}>
          <span style={styles.eyebrowDash} />
          Major Explorer
        </span>
        <h1 style={styles.title}>Majors are coming soon</h1>
        <p style={styles.text}>
          We're building a major explorer that maps to your assessment results.
          In the meantime, you can browse universities and their programs directly.
        </p>
        <span style={styles.badge}>In development</span>
        <div>
          <Link to="/universities" style={styles.homeLink}>Browse Universities →</Link>
        </div>
      </div>
    </StudentLayout>
  );
}
