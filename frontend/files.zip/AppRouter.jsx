import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { useEffect } from "react";

import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";
import ForgotPassword from "../pages/auth/ForgotPassword";
import Profile from "../pages/profile/Profile";
import EditProfile from "../pages/profile/EditProfile";
import AdminDashboard from "../pages/admin/AdminDashboard";
import Users from "../pages/admin/Users";
import Questions from "../pages/admin/Questions";
import ProtectedRoute from "./ProtectedRoute";
import Unauthorized from "../pages/Unauthorized";
import SuperAdminUsers from "../pages/admin/SuperAdminUsers";
import SuperAdminPanel from "../pages/admin/SuperAdminPanel";
import ActivityLogs from "../pages/admin/ActivityLogs";
import AboutUs from "../pages/about/AboutUs";
import AdminUniversities from "../pages/admin/AdminUniversities";
import Universities from "../pages/student/Universities";
import StudentDashboard from "../pages/student/StudentDashboard";
import Careers from "../pages/student/Careers";
import Majors from "../pages/student/Majors";

// React Router doesn't auto-scroll to a #hash on client-side navigation.
// This makes links like "/about#contact" actually land on that section.
function ScrollToHash() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.replace("#", ""));
      if (el) {
        setTimeout(() => el.scrollIntoView({ behavior: "smooth" }), 50);
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);

  return null;
}

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <ScrollToHash />
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />

        <Route path="/login" element={<Login />} />
        <Route  path="/about" element={<AboutUs />}/>
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/profile" element={<ProtectedRoute allowedRoles={[1,2]}><Profile /></ProtectedRoute>}/>
        <Route path="/profile/edit" element={<EditProfile />} />
        <Route  path="/about" element={<AboutUs />}/>
        <Route path="/admin/dashboard" element={<AdminDashboard />}/>
        <Route path="/admin/users" element={ <ProtectedRoute allowedRoles={[1,3]}> <Users /></ProtectedRoute> }/>
        <Route path="/admin/questions" element={ <ProtectedRoute allowedRoles={[1,3]}>  <Questions /></ProtectedRoute>}/>
        <Route path="/unauthorized" element={<Unauthorized />} />
        <Route path="/admin/dashboard" element={ <ProtectedRoute allowedRoles={[1,3]}> <AdminDashboard /> </ProtectedRoute>}/>
        <Route path="/admin/super-users" element={<ProtectedRoute allowedRoles={[3]}><SuperAdminUsers /></ProtectedRoute>}/>
        <Route path="/admin/super" element={ <ProtectedRoute allowedRoles={[3]}><SuperAdminPanel /></ProtectedRoute>}/>
        <Route path="/admin/activity" element={<ProtectedRoute allowedRoles={[3]}> <ActivityLogs /></ProtectedRoute>}/>
        <Route path="/admin/universities" element={<AdminUniversities/>}/>
        <Route path="/universities" element={<ProtectedRoute allowedRoles={[1, 2, 3]}><Universities /></ProtectedRoute>}/>
        <Route path="/student/dashboard" element={<ProtectedRoute allowedRoles={[1, 2, 3]}><StudentDashboard /></ProtectedRoute>}/>
        <Route path="/careers" element={<ProtectedRoute allowedRoles={[1, 2, 3]}><Careers /></ProtectedRoute>}/>
        <Route path="/majors" element={<ProtectedRoute allowedRoles={[1, 2, 3]}><Majors /></ProtectedRoute>}/>


      </Routes>
    </BrowserRouter>
  );
}