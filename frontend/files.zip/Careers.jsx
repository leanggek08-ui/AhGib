import { Link } from "react-router-dom";
import StudentLayout from "../../layouts/StudentLayout";
import { styles } from "../../styles/comingSoonStyles";

export default function Careers() {
  return (
    <StudentLayout>
      <div style={styles.wrap}>
        <div style={styles.icon}>💼</div>
        <span style={styles.eyebrow}>
          <span style={styles.eyebrowDash} />
          Career Explorer
        </span>
        <h1 style={styles.title}>Careers are coming soon</h1>
        <p style={styles.text}>
          We're building a career explorer that maps to your assessment results.
          For now, take a look at what AhGib is building on the About page, or
          head back to your dashboard.
        </p>
        <span style={styles.badge}>In development</span>
        <div>
          <Link to="/student/dashboard" style={styles.homeLink}>← Back to Dashboard</Link>
        </div>
      </div>
    </StudentLayout>
  );
}
